package com.prolijo.viajesrentables

import android.content.Context
import android.content.SharedPreferences

/**
 * Ajustes guardados en SharedPreferences (local, en el teléfono).
 * Los valores por defecto son EJEMPLOS para Monterrey, no los datos
 * reales del auto de Prolijo: hay que cambiarlos en la pantalla
 * principal por los reales (gasolina, rendimiento, costos y metas).
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var settings: TripSettings
        get() = TripSettings(
            gasPricePerLiter = prefs.getFloat(KEY_GAS, 24.90f).toDouble(),
            kmPerLiter = prefs.getFloat(KEY_KM_L, 14.0f).toDouble(),
            maintenancePerKm = prefs.getFloat(KEY_MAINT, 1.20f).toDouble(),
            commissionFraction = prefs.getFloat(KEY_COMMISSION, 0.0f).toDouble(),
            targetPerKm = prefs.getFloat(KEY_TARGET_KM, 8.0f).toDouble(),
            targetPerHour = prefs.getFloat(KEY_TARGET_HOUR, 200.0f).toDouble()
        )
        set(value) {
            prefs.edit()
                .putFloat(KEY_GAS, value.gasPricePerLiter.toFloat())
                .putFloat(KEY_KM_L, value.kmPerLiter.toFloat())
                .putFloat(KEY_MAINT, value.maintenancePerKm.toFloat())
                .putFloat(KEY_COMMISSION, value.commissionFraction.toFloat())
                .putFloat(KEY_TARGET_KM, value.targetPerKm.toFloat())
                .putFloat(KEY_TARGET_HOUR, value.targetPerHour.toFloat())
                .apply()
        }

    /** ¿El usuario ya cambió los valores de ejemplo por los suyos? */
    var settingsConfirmed: Boolean
        get() = prefs.getBoolean(KEY_CONFIRMED, false)
        set(value) = prefs.edit().putBoolean(KEY_CONFIRMED, value).apply()

    var overlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY, value).apply()

    companion object {
        private const val PREFS_NAME = "viajes_rentables_prefs"
        private const val KEY_GAS = "gas_price_per_liter"
        private const val KEY_KM_L = "km_per_liter"
        private const val KEY_MAINT = "maintenance_per_km"
        private const val KEY_COMMISSION = "commission_fraction"
        private const val KEY_TARGET_KM = "target_per_km"
        private const val KEY_TARGET_HOUR = "target_per_hour"
        private const val KEY_CONFIRMED = "settings_confirmed"
        private const val KEY_OVERLAY = "overlay_enabled"
    }
}
