package com.prolijo.viajesrentables

/**
 * Extrae tarifa, km y minutos del texto de una oferta de Uber / DiDi.
 *
 * Formatos que se ven en pantalla en México (español):
 *   "$180", "$180.50", "180 MXN", "Tarifa: $180"
 *   "12 km", "12.5 km", "2 km de recogida", "Distancia: 14 km"
 *   "25 min", "25 minutos", "Tiempo estimado: 25 min"
 *
 * Es tolerante: quita comas de miles ("$1,250"), acepta coma decimal
 * ("12,5 km") y busca primero las etiquetas; si no las hay, usa el
 * número con $ para la tarifa, el número con "km" para los km y el
 * número con "min" para los minutos.
 *
 * Devuelve null en un campo cuando no lo encuentra. El llamador decide
 * si con lo que hay alcanza para calcular (se necesitan los 3 datos).
 */
data class ParsedOffer(
    val fare: Double?,
    val tripKm: Double?,
    val pickupKm: Double?,
    val minutes: Double?,
    val rawText: String
) {
    /** Km totales = viaje + recogida (si no hay recogida, solo viaje). */
    val totalKm: Double?
        get() = when {
            tripKm == null -> null
            pickupKm == null -> tripKm
            else -> tripKm + pickupKm
        }

    val isComplete: Boolean
        get() = fare != null && totalKm != null && minutes != null

    fun toTripInput(app: String): TripInput? {
        val total = totalKm
        if (fare == null || total == null || minutes == null) return null
        return TripInput(app = app, fare = fare, totalKm = total, minutes = minutes)
    }
}

object OfferParser {

    private fun cleanNumber(raw: String): Double? {
        // "$1,250.50" -> 1250.50 ; "12,5" -> 12.5
        val cleaned = raw.trim()
            .replace("$", "")
            .replace("MXN", "", ignoreCase = true)
            .replace(" ", "")
        return try {
            if (cleaned.contains(",") && !cleaned.contains(".")) {
                cleaned.replace(",", ".").toDouble()
            } else {
                cleaned.replace(",", "").toDouble()
            }
        } catch (_: NumberFormatException) {
            null
        }
    }

    private val numberPattern = """(\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:[.,]\d+)?)"""

    private val fareRegex = Regex(
        """(?:tarifa|pago|ganancia|total|precio|te pagan|ofrece)[^\d$]{0,12}\$?\s*$numberPattern""",
        RegexOption.IGNORE_CASE
    )
    private val fareDollarRegex = Regex("""\$\s*$numberPattern""")
    private val pickupRegex = Regex(
        """(?:recogida|recoger|para llegar|distancia de recogida)[^\d]{0,20}$numberPattern\s*(?:km|kilómetros?)""",
        RegexOption.IGNORE_CASE
    )
    private val kmRegex = Regex("""$numberPattern\s*(?:km|kilómetros?)""", RegexOption.IGNORE_CASE)
    private val minutesRegex = Regex(
        """$numberPattern\s*(?:min(?:utos?)?|mins)""",
        RegexOption.IGNORE_CASE
    )

    fun parse(text: String): ParsedOffer {
        val normalized = text.replace("\u00A0", " ")

        val fare = fareRegex.find(normalized)?.groupValues?.getOrNull(1)?.let(::cleanNumber)
            ?: fareDollarRegex.find(normalized)?.groupValues?.getOrNull(1)?.let(::cleanNumber)

        // Km de recogida, si aparece etiquetado.
        val pickupKm = pickupRegex.find(normalized)?.groupValues?.getOrNull(1)?.let(::cleanNumber)

        // Todos los valores en km, en orden de aparición.
        val allKm = kmRegex.findAll(normalized)
            .mapNotNull { it.groupValues.getOrNull(1)?.let(::cleanNumber) }
            .toList()

        // El km del viaje es el primer valor en km que no sea la recogida.
        // Si solo hay un valor, es el del viaje.
        val tripKm = when {
            allKm.isEmpty() -> null
            pickupKm != null && allKm.size >= 2 ->
                allKm.firstOrNull { it != pickupKm } ?: allKm.first()
            else -> allKm.first()
        }

        val minutes = minutesRegex.find(normalized)?.groupValues?.getOrNull(1)?.let(::cleanNumber)

        return ParsedOffer(
            fare = fare,
            tripKm = tripKm,
            pickupKm = pickupKm,
            minutes = minutes,
            rawText = text
        )
    }
}
