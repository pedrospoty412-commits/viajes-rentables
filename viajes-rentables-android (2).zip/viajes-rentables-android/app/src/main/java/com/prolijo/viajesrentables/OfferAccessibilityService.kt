package com.prolijo.viajesrentables

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Servicio de accesibilidad.
 *
 * Qué hace:
 *  1. Detecta cuando la ventana activa es Uber Driver o DiDi Conductor.
 *  2. Lee el texto visible de la pantalla (nodos de accesibilidad).
 *     Esto es lo más fiable: no necesita captura de pantalla.
 *  3. Si ese texto tiene tarifa, km y minutos, calcula la rentabilidad
 *     y le pide a OverlayService que muestre la burbuja.
 *  4. Si el texto de los nodos no alcanza, pide una captura con OCR
 *     (ScreenCaptureHelper + ML Kit) como segundo intento.
 *
 * Qué NO hace:
 *  - NO acepta ni rechaza viajes por ti. Solo te aconseja.
 *  - NO toca botones de Uber / DiDi, NO escribe, NO envía datos a ningún
 *    servidor. Todo se calcula en el teléfono.
 *
 * Paquetes que vigila (pueden cambiar con las actualizaciones de las apps;
 * si Uber / DiDi cambian el paquete, agrégalo en DRIVER_PACKAGES):
 *  - Uber Driver: com.ubercab.driver
 *  - DiDi Conductor (México): com.sdu.didi.psnger / com.didiglobal.drivermx
 *    Se incluyen varios paquetes conocidos de DiDi para cubrir variantes.
 */
class OfferAccessibilityService : AccessibilityService() {

    private lateinit var settingsStore: SettingsStore
    private lateinit var historyStore: TripHistoryStore
    private var lastOfferText: String? = null
    private var lastOfferAt: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        settingsStore = SettingsStore(this)
        historyStore = TripHistoryStore(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!settingsStore.overlayEnabled) return

        // Solo nos interesan cambios de ventana / contenido.
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return

        val packageName = event.packageName?.toString() ?: return
        val app = appNameFor(packageName) ?: return

        val root = rootInActiveWindow ?: return
        val text = collectText(root)
        if (text.isBlank()) return

        // Evitar evaluar la misma oferta una y otra vez.
        val now = System.currentTimeMillis()
        if (text == lastOfferText && now - lastOfferAt < 5_000) return
        lastOfferText = text
        lastOfferAt = now

        evaluateText(text, app)
    }

    private fun evaluateText(text: String, app: String) {
        val parsed = OfferParser.parse(text)
        val input = parsed.toTripInput(app)
        if (input != null) {
            showResult(input)
            return
        }

        // Segundo intento: captura de pantalla + OCR (ML Kit).
        // Solo si faltan datos en el texto de los nodos.
        ScreenCaptureHelper.requestCapture(this) { bitmap ->
            if (bitmap == null) return@requestCapture
            OcrHelper.recognize(bitmap) { ocrText ->
                val parsedOcr = OfferParser.parse(ocrText)
                parsedOcr.toTripInput(app)?.let { showResult(it) }
            }
        }
    }

    private fun showResult(input: TripInput) {
        val result = ProfitCalculator.evaluate(input, settingsStore.settings)
        historyStore.save(result)
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW_RESULT
            putExtra(OverlayService.EXTRA_FARE, result.input.fare)
            putExtra(OverlayService.EXTRA_KM, result.input.totalKm)
            putExtra(OverlayService.EXTRA_MINUTES, result.input.minutes)
            putExtra(OverlayService.EXTRA_APP, result.input.app)
            putExtra(OverlayService.EXTRA_PROFIT, result.netProfit)
            putExtra(OverlayService.EXTRA_PER_KM, result.netPerKm)
            putExtra(OverlayService.EXTRA_PER_HOUR, result.netPerHour)
            putExtra(OverlayService.EXTRA_VERDICT, result.verdict.name)
            putExtra(OverlayService.EXTRA_REASON, result.reason)
        }
        startService(intent)
    }

    private fun appNameFor(packageName: String): String? = when (packageName) {
        "com.ubercab.driver" -> "Uber"
        "com.sdu.didi.psnger",
        "com.didiglobal.drivermx",
        "com.didiglobal.driver",
        "com.sdu.didi.driver" -> "DiDi"
        else -> null
    }

    private fun collectText(node: AccessibilityNodeInfo, out: StringBuilder = StringBuilder()): String {
        node.text?.let { out.append(it).append("\n") }
        node.contentDescription?.let { out.append(it).append("\n") }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, out) }
        }
        return out.toString()
    }

    override fun onInterrupt() {
        // El sistema interrumpe el servicio: no hay nada que limpiar aquí.
    }

    companion object {
        /** Paquetes vigilados. Ver comentario de la clase si cambian. */
        val DRIVER_PACKAGES = setOf(
            "com.ubercab.driver",
            "com.sdu.didi.psnger",
            "com.didiglobal.drivermx",
            "com.didiglobal.driver",
            "com.sdu.didi.driver"
        )
    }
}
