package com.prolijo.viajesrentables

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Historial local de viajes evaluados. Almacenamiento simple con
 * SharedPreferences + JSON (sin base de datos externa, todo queda
 * en el teléfono). Guarda fecha, app, tarifa, km, minutos y veredicto.
 */
data class TripRecord(
    val timestampMillis: Long,
    val app: String,
    val fare: Double,
    val totalKm: Double,
    val minutes: Double,
    val netProfit: Double,
    val verdict: Verdict
)

class TripHistoryStore(context: Context) {

    private val prefs =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun save(result: TripResult) {
        val list = load().toMutableList()
        list.add(
            0, TripRecord(
                timestampMillis = System.currentTimeMillis(),
                app = result.input.app,
                fare = result.input.fare,
                totalKm = result.input.totalKm,
                minutes = result.input.minutes,
                netProfit = result.netProfit,
                verdict = result.verdict
            )
        )
        // Guardar solo los últimos 200, para no crecer sin límite.
        val trimmed = list.take(200)
        val array = JSONArray()
        for (record in trimmed) {
            array.put(
                JSONObject()
                    .put("ts", record.timestampMillis)
                    .put("app", record.app)
                    .put("fare", record.fare)
                    .put("km", record.totalKm)
                    .put("min", record.minutes)
                    .put("profit", record.netProfit)
                    .put("verdict", record.verdict.name)
            )
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    fun load(): List<TripRecord> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val obj = array.getJSONObject(i)
                TripRecord(
                    timestampMillis = obj.getLong("ts"),
                    app = obj.getString("app"),
                    fare = obj.getDouble("fare"),
                    totalKm = obj.getDouble("km"),
                    minutes = obj.getDouble("min"),
                    netProfit = obj.getDouble("profit"),
                    verdict = Verdict.valueOf(obj.getString("verdict"))
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Resumen de hoy: viajes guardados, ganancia neta y km. */
    fun todaySummary(): Triple<Int, Double, Double> {
        val startOfDay = System.currentTimeMillis() - (System.currentTimeMillis() % 86_400_000L)
        val today = load().filter { it.timestampMillis >= startOfDay }
        return Triple(
            today.size,
            today.sumOf { it.netProfit },
            today.sumOf { it.totalKm }
        )
    }

    fun clear() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    companion object {
        private const val PREFS_NAME = "viajes_rentables_history"
        private const val KEY_HISTORY = "trips_json"
    }
}
