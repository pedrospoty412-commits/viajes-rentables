package com.prolijo.viajesrentables

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat

/**
 * Servicio en primer plano que dibuja la tarjeta flotante encima de
 * Uber / DiDi con el veredicto.
 *
 * Muestra: SÍ CONVIENE / APENAS / NO CONVIENE, ganancia neta, $/km,
 * $/hora y el porqué. La tarjeta se puede arrastrar con el dedo y
 * cerrar con el botón "Cerrar".
 *
 * NO acepta viajes automáticamente: solo aconseja. La decisión de
 * aceptar o rechazar siempre es del conductor, en la app de Uber / DiDi.
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW_RESULT) {
            showResult(intent)
        } else if (intent?.action == ACTION_HIDE) {
            hideOverlay()
        }
        return START_STICKY
    }

    private fun showResult(intent: Intent) {
        val verdict = Verdict.valueOf(
            intent.getStringExtra(EXTRA_VERDICT) ?: Verdict.APENAS.name
        )
        val profit = intent.getDoubleExtra(EXTRA_PROFIT, 0.0)
        val perKm = intent.getDoubleExtra(EXTRA_PER_KM, 0.0)
        val perHour = intent.getDoubleExtra(EXTRA_PER_HOUR, 0.0)
        val app = intent.getStringExtra(EXTRA_APP) ?: ""
        val fare = intent.getDoubleExtra(EXTRA_FARE, 0.0)
        val km = intent.getDoubleExtra(EXTRA_KM, 0.0)
        val minutes = intent.getDoubleExtra(EXTRA_MINUTES, 0.0)
        val reason = intent.getStringExtra(EXTRA_REASON) ?: ""

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        hideOverlay()

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_card, null)
        view.findViewById<TextView>(R.id.overlay_app).text =
            if (app.isNotBlank()) "$app · ${ProfitCalculator.money(fare)} · $km km · ${minutes.toInt()} min"
            else "${ProfitCalculator.money(fare)} · $km km · ${minutes.toInt()} min"

        val verdictView = view.findViewById<TextView>(R.id.overlay_verdict)
        verdictView.text = ProfitCalculator.verdictLabel(verdict)
        val color = when (verdict) {
            Verdict.SI_CONVIENE -> 0xFF2E7D32.toInt() // verde
            Verdict.APENAS -> 0xFFEF6C00.toInt()      // naranja
            Verdict.NO_CONVIENE -> 0xFFC62828.toInt() // rojo
        }
        verdictView.setBackgroundColor(color)

        view.findViewById<TextView>(R.id.overlay_profit).text =
            "Ganancia: ${ProfitCalculator.money(profit)}"
        view.findViewById<TextView>(R.id.overlay_per_km).text =
            "Por km: ${ProfitCalculator.money(perKm)}"
        view.findViewById<TextView>(R.id.overlay_per_hour).text =
            "Por hora: ${ProfitCalculator.money(perHour)}"
        view.findViewById<TextView>(R.id.overlay_reason).text = reason
        view.findViewById<Button>(R.id.overlay_close).setOnClickListener { hideOverlay() }

        // La tarjeta se arrastra con el dedo.
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        val params = windowParams()
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }

        overlayView = view
        wm.addView(view, params)
    }

    private fun windowParams(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 200
        }
    }

    private fun hideOverlay() {
        overlayView?.let { windowManager?.removeView(it) }
        overlayView = null
    }

    private fun buildNotification(): Notification {
        val channelId = "viajes_rentables_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Burbuja de viajes rentables",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Viajes Rentables activo")
            .setContentText("Leyendo ofertas de Uber / DiDi para decirte si convienen.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW_RESULT = "com.prolijo.viajesrentables.SHOW_RESULT"
        const val ACTION_HIDE = "com.prolijo.viajesrentables.HIDE"
        const val EXTRA_FARE = "fare"
        const val EXTRA_KM = "km"
        const val EXTRA_MINUTES = "minutes"
        const val EXTRA_APP = "app"
        const val EXTRA_PROFIT = "profit"
        const val EXTRA_PER_KM = "per_km"
        const val EXTRA_PER_HOUR = "per_hour"
        const val EXTRA_VERDICT = "verdict"
        const val EXTRA_REASON = "reason"
        private const val NOTIFICATION_ID = 1
    }
}
