package com.prolijo.viajesrentables

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pantalla principal: ajustes, interruptor de la burbuja, permisos
 * y el historial de viajes evaluados.
 *
 * Permisos que pide, en orden:
 *  1. Dibujar sobre otras apps (SYSTEM_ALERT_WINDOW) — para la burbuja.
 *  2. Servicio de accesibilidad — para leer el texto de la oferta.
 *     Se activa en Ajustes del teléfono > Accesibilidad > Viajes Rentables.
 *  3. Captura de pantalla (MediaProjection, opcional) — solo como
 *     segundo intento de OCR cuando el texto de accesibilidad no alcanza.
 *
 * La app NO acepta viajes por ti y NO envía tus datos a ningún servidor.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var settingsStore: SettingsStore
    private lateinit var historyStore: TripHistoryStore

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            ScreenCaptureHelper.storeConsent(result.resultCode, result.data)
            Toast.makeText(this, "Captura de pantalla permitida (OCR listo).", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                this,
                "Sin captura de pantalla: la app usará solo el texto de la oferta.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settingsStore = SettingsStore(this)
        historyStore = TripHistoryStore(this)

        val gasInput = findViewById<EditText>(R.id.input_gas_price)
        val kmLInput = findViewById<EditText>(R.id.input_km_per_liter)
        val maintInput = findViewById<EditText>(R.id.input_maintenance)
        val commissionInput = findViewById<EditText>(R.id.input_commission)
        val targetKmInput = findViewById<EditText>(R.id.input_target_km)
        val targetHourInput = findViewById<EditText>(R.id.input_target_hour)
        val enableSwitch = findViewById<Switch>(R.id.switch_enable)
        val statusText = findViewById<TextView>(R.id.text_status)
        val historyText = findViewById<TextView>(R.id.text_history)

        fun loadSettingsIntoForm() {
            val s = settingsStore.settings
            gasInput.setText(s.gasPricePerLiter.toString())
            kmLInput.setText(s.kmPerLiter.toString())
            maintInput.setText(s.maintenancePerKm.toString())
            commissionInput.setText((s.commissionFraction * 100).toString())
            targetKmInput.setText(s.targetPerKm.toString())
            targetHourInput.setText(s.targetPerHour.toString())
            enableSwitch.isChecked = settingsStore.overlayEnabled
        }
        loadSettingsIntoForm()

        findViewById<Button>(R.id.button_save_settings).setOnClickListener {
            val settings = TripSettings(
                gasPricePerLiter = gasInput.text.toString().toDoubleOrNull() ?: 24.90,
                kmPerLiter = kmLInput.text.toString().toDoubleOrNull() ?: 14.0,
                maintenancePerKm = maintInput.text.toString().toDoubleOrNull() ?: 1.20,
                commissionFraction = (commissionInput.text.toString().toDoubleOrNull() ?: 0.0) / 100.0,
                targetPerKm = targetKmInput.text.toString().toDoubleOrNull() ?: 8.0,
                targetPerHour = targetHourInput.text.toString().toDoubleOrNull() ?: 200.0
            )
            settingsStore.settings = settings
            settingsStore.settingsConfirmed = true
            Toast.makeText(this, "Ajustes guardados.", Toast.LENGTH_SHORT).show()
            refreshStatus(statusText)
        }

        enableSwitch.setOnCheckedChangeListener { _, isChecked ->
            settingsStore.overlayEnabled = isChecked
            if (isChecked) {
                ensureOverlayPermission()
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(
                    this,
                    "Burbuja activada. Ahora activa también el servicio de accesibilidad.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                stopService(Intent(this, OverlayService::class.java))
                startService(Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_HIDE
                })
            }
            refreshStatus(statusText)
        }

        findViewById<Button>(R.id.button_overlay_permission).setOnClickListener {
            ensureOverlayPermission()
        }
        findViewById<Button>(R.id.button_accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(
                this,
                "Busca 'Viajes Rentables' en Accesibilidad y actívalo.",
                Toast.LENGTH_LONG
            ).show()
        }
        findViewById<Button>(R.id.button_capture_permission).setOnClickListener {
            captureLauncher.launch(ScreenCaptureHelper.createCaptureIntent(this))
        }
        findViewById<Button>(R.id.button_clear_history).setOnClickListener {
            historyStore.clear()
            refreshHistory(historyText)
            Toast.makeText(this, "Historial borrado.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.button_test).setOnClickListener {
            // Prueba rápida con los datos de ejemplo de la app web:
            // DiDi, $180, 12 km de viaje + 2 km de recogida, 25 min.
            val result = ProfitCalculator.evaluate(
                TripInput(app = "DiDi", fare = 180.0, totalKm = 14.0, minutes = 25.0),
                settingsStore.settings
            )
            historyStore.save(result)
            val intent = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_SHOW_RESULT
                putExtra(OverlayService.EXTRA_FARE, result.input.fare)
                putExtra(OverlayService.EXTRA_KM, result.input.totalKm)
                putExtra(OverlayService.EXTRA_MINUTES, result.input.minutes)
                putExtra(OverlayService.EXTRA_APP, result.input.app)
                putExtra(OverlayService.EXTRA_PROFIT, result.netProfit)
                putExtra(OverlayService.EXTRA_PER_KM, result.netPerKm)
                putExtra(OverlayService.EXTRA_PER_HOUR, result.netPerHour)
                putExtra(OverlayService.EXTRA_VERDICT, result.verdict.name)
                putExtra(OverlayService.EXTRA_REASON, result.reason)
            }
            startService(intent)
            refreshHistory(historyText)
            Toast.makeText(this, "Prueba: se mostró la burbuja con el ejemplo.", Toast.LENGTH_LONG).show()
        }

        refreshStatus(statusText)
        refreshHistory(historyText)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus(findViewById(R.id.text_status))
        refreshHistory(findViewById(R.id.text_history))
    }

    private fun ensureOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(
                this,
                "Activa 'Permitir mostrar sobre otras apps'.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun refreshStatus(statusText: TextView) {
        val overlayOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
        val captureOk = ScreenCaptureHelper.hasConsent()
        statusText.text = buildString {
            append("Burbuja: ${if (settingsStore.overlayEnabled) "activada" else "apagada"}\n")
            append("Permiso de superposición: ${if (overlayOk) "sí" else "falta"}\n")
            append("Accesibilidad: actívala en Ajustes del teléfono\n")
            append("Captura de pantalla (OCR): ${if (captureOk) "sí" else "opcional, falta"}")
        }
    }

    private fun refreshHistory(historyText: TextView) {
        val (count, profit, km) = historyStore.todaySummary()
        val dateFormat = SimpleDateFormat("dd/MM HH:mm", Locale("es", "MX"))
        val lines = historyStore.load().take(20).joinToString("\n") { record ->
            val date = dateFormat.format(Date(record.timestampMillis))
            "$date · ${record.app} · ${ProfitCalculator.money(record.fare)} · " +
                "${record.totalKm} km · ${ProfitCalculator.verdictLabel(record.verdict)} · " +
                "ganancia ${ProfitCalculator.money(record.netProfit)}"
        }
        historyText.text = buildString {
            append("Hoy: $count viajes · ganancia neta ${ProfitCalculator.money(profit)} · $km km\n\n")
            append(if (lines.isBlank()) "Aún no hay viajes guardados." else lines)
        }
    }
}
