package com.prolijo.viajesrentables

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Captura de pantalla con MediaProjection (permiso del sistema).
 *
 * Flujo real en Android:
 *  1. MainActivity pide el permiso con MediaProjectionManager.createScreenCaptureIntent()
 *     y guarda el resultCode + data en CaptureSession (memoria).
 *  2. Cuando el servicio de accesibilidad necesita OCR, este helper usa
 *     esa sesión para crear un VirtualDisplay + ImageReader, toma un
 *     frame y lo convierte a Bitmap.
 *
 * Limitación honesta: MediaProjection muestra el aviso del sistema
 * ("¿Permitir que Viajes Rentables capture la pantalla?") y el usuario
 * debe aceptarlo. Sin ese permiso, la app usa solo el texto de los
 * nodos de accesibilidad, que en la mayoría de ofertas ya alcanza.
 * El Bitmap nunca sale del teléfono y no se sube a ningún servidor.
 */
object ScreenCaptureHelper {

    const val REQUEST_CAPTURE = 1001

    // Sesión guardada por MainActivity tras el consentimiento del usuario.
    var resultCode: Int = Activity.RESULT_CANCELED
        private set
    var resultData: Intent? = null
        private set

    fun storeConsent(resultCode: Int, data: Intent?) {
        this.resultCode = resultCode
        this.resultData = data
    }

    fun hasConsent(): Boolean = resultData != null && resultCode == Activity.RESULT_OK

    fun createCaptureIntent(context: Context): Intent {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as MediaProjectionManager
        return manager.createScreenCaptureIntent()
    }

    fun requestCapture(context: Context, onBitmap: (Bitmap?) -> Unit) {
        val data = resultData
        if (!hasConsent() || data == null) {
            onBitmap(null)
            return
        }
        try {
            val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager
            val projection: MediaProjection =
                manager.getMediaProjection(resultCode, data) ?: run {
                    onBitmap(null); return
                }

            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val display: VirtualDisplay = projection.createVirtualDisplay(
                "viajes-rentables-capture",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )

            // Esperar un frame y convertirlo a Bitmap.
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    val image = reader.acquireLatestImage()
                    val bitmap: Bitmap? = image?.let {
                        val plane = it.planes[0]
                        val buffer = plane.buffer
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * width
                        val bmp = Bitmap.createBitmap(
                            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                        )
                        bmp.copyPixelsFromBuffer(buffer)
                        it.close()
                        Bitmap.createBitmap(bmp, 0, 0, width, height)
                    }
                    onBitmap(bitmap)
                } catch (_: Exception) {
                    onBitmap(null)
                } finally {
                    display.release()
                    reader.close()
                    projection.stop()
                }
            }, 500)
        } catch (_: Exception) {
            onBitmap(null)
        }
    }
}
