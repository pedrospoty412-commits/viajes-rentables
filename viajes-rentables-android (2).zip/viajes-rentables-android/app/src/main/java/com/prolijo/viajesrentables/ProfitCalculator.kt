package com.prolijo.viajesrentables

import kotlin.math.roundToInt

/**
 * Calculadora de rentabilidad — objeto puro, sin Android, para poder
 * probarla con tests unitarios. Es la misma lógica que la app web
 * "Viajes Rentables - Uber y DiDi":
 *
 *  - Entradas: tarifa ofrecida, km totales (viaje + recogida), minutos.
 *  - Ajustes: precio de gasolina, rendimiento del auto, costo de
 *    mantenimiento / otros por km, comisión %, metas por km y por hora.
 *
 * Nota sobre la comisión: en México la oferta de Uber / DiDi normalmente
 * ya muestra lo que te pagan a ti, no el total del pasajero. Por eso el
 * valor por defecto es 0 %. Si tu oferta es el total bruto, sube la
 * comisión en Ajustes (por ejemplo 25 % Uber, 20 % DiDi).
 */
enum class Verdict {
    SI_CONVIENE, APENAS, NO_CONVIENE
}

data class TripSettings(
    /** Precio de la gasolina, MXN por litro. Ejemplo Monterrey. */
    val gasPricePerLiter: Double = 24.90,
    /** Rendimiento del auto, km por litro. Ejemplo. */
    val kmPerLiter: Double = 14.0,
    /** Mantenimiento, desgaste y otros, MXN por km. Ejemplo. */
    val maintenancePerKm: Double = 1.20,
    /** Comisión sobre la tarifa, 0.0 - 1.0. 0 % por defecto (ver nota arriba). */
    val commissionFraction: Double = 0.0,
    /** Meta de ganancia neta, MXN por km total. Ejemplo. */
    val targetPerKm: Double = 8.0,
    /** Meta de ganancia neta, MXN por hora. Ejemplo. */
    val targetPerHour: Double = 200.0
) {
    /** Costo total por km: gasolina + mantenimiento. */
    val costPerKm: Double
        get() = if (kmPerLiter > 0) gasPricePerLiter / kmPerLiter + maintenancePerKm
        else maintenancePerKm
}

data class TripInput(
    val app: String = "Uber", // "Uber" o "DiDi"
    val fare: Double,         // MXN que te pagan por el viaje
    val totalKm: Double,      // km del viaje + km de recogida
    val minutes: Double       // minutos estimados del viaje
)

data class TripResult(
    val input: TripInput,
    val settings: TripSettings,
    val grossFare: Double,
    val netFare: Double,      // tarifa después de comisión
    val totalCost: Double,    // costo total del viaje
    val netProfit: Double,    // ganancia neta
    val netPerKm: Double,     // ganancia neta por km total
    val grossPerKm: Double,   // tarifa bruta por km total
    val netPerHour: Double,   // ganancia neta por hora
    val grossPerHour: Double, // tarifa bruta por hora
    val verdict: Verdict,
    val reason: String        // explicación en español, clara y corta
)

object ProfitCalculator {

    fun evaluate(input: TripInput, settings: TripSettings): TripResult {
        require(input.fare >= 0) { "La tarifa no puede ser negativa" }
        require(input.totalKm > 0) { "Los km totales deben ser mayores a 0" }
        require(input.minutes > 0) { "Los minutos deben ser mayores a 0" }

        val netFare = input.fare * (1.0 - settings.commissionFraction.coerceIn(0.0, 1.0))
        val totalCost = input.totalKm * settings.costPerKm
        val netProfit = netFare - totalCost
        val hours = input.minutes / 60.0

        val netPerKm = netProfit / input.totalKm
        val grossPerKm = input.fare / input.totalKm
        val netPerHour = netProfit / hours
        val grossPerHour = input.fare / hours

        val (verdict, reason) = when {
            netProfit <= 0 ->
                Verdict.NO_CONVIENE to
                    "No conviene: pierdes dinero, la tarifa no cubre ni la gasolina y el desgaste."

            netPerKm >= settings.targetPerKm && netPerHour >= settings.targetPerHour ->
                Verdict.SI_CONVIENE to
                    "Sí conviene: superas tu meta por km y por hora."

            netPerKm >= settings.targetPerKm || netPerHour >= settings.targetPerHour ->
                Verdict.APENAS to
                    "Apenas conviene: cumples una meta pero no las dos. Solo si estás cerca o sin otro viaje."

            else ->
                Verdict.NO_CONVIENE to
                    "No conviene: ganas poco por km y por hora, por debajo de tus metas."
        }

        return TripResult(
            input = input,
            settings = settings,
            grossFare = input.fare,
            netFare = netFare,
            totalCost = totalCost,
            netProfit = netProfit,
            netPerKm = netPerKm,
            grossPerKm = grossPerKm,
            netPerHour = netPerHour,
            grossPerHour = grossPerHour,
            verdict = verdict,
            reason = reason
        )
    }

    fun verdictLabel(verdict: Verdict): String = when (verdict) {
        Verdict.SI_CONVIENE -> "SÍ CONVIENE"
        Verdict.APENAS -> "APENAS"
        Verdict.NO_CONVIENE -> "NO CONVIENE"
    }

    /** Formato MXN, por ejemplo $131.22 */
    fun money(value: Double): String = "$" + "%,.2f".format(value)

    fun round2(value: Double): Double = (value * 100).roundToInt() / 100.0
}
