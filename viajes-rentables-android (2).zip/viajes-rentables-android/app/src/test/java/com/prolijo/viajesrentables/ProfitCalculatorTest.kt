package com.prolijo.viajesrentables

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfitCalculatorTest {

    // Ajustes de ejemplo de Monterrey, iguales a los de la app.
    private val settings = TripSettings(
        gasPricePerLiter = 24.90,
        kmPerLiter = 14.0,
        maintenancePerKm = 1.20,
        commissionFraction = 0.0,
        targetPerKm = 8.0,
        targetPerHour = 200.0
    )

    @Test
    fun ejemploWebApp_conviene() {
        // DiDi, $180, 12 km de viaje + 2 km de recogida = 14 km, 25 min.
        val result = ProfitCalculator.evaluate(
            TripInput(app = "DiDi", fare = 180.0, totalKm = 14.0, minutes = 25.0),
            settings
        )
        assertEquals(Verdict.SI_CONVIENE, result.verdict)
        assertTrue(result.netProfit > 0)
        // Costo por km: 24.90 / 14 + 1.20 = 2.98; costo total 41.70; ganancia 138.30
        assertEquals(138.30, result.netProfit, 0.01)
        assertEquals(9.88, result.netPerKm, 0.01)
        assertTrue(result.netPerHour > 200.0)
    }

    @Test
    fun viajeCortoBarato_noConviene() {
        val result = ProfitCalculator.evaluate(
            TripInput(app = "Uber", fare = 35.0, totalKm = 12.0, minutes = 30.0),
            settings
        )
        assertEquals(Verdict.NO_CONVIENE, result.verdict)
        assertTrue(result.netProfit < 10.0)
    }

    @Test
    fun gananciaCero_noConviene() {
        val cost = 14.0 * settings.costPerKm
        val result = ProfitCalculator.evaluate(
            TripInput(app = "Uber", fare = cost, totalKm = 14.0, minutes = 25.0),
            settings
        )
        assertEquals(Verdict.NO_CONVIENE, result.verdict)
        assertEquals(0.0, result.netProfit, 0.01)
    }

    @Test
    fun conComision_bajaLaGanancia() {
        val withCommission = settings.copy(commissionFraction = 0.25)
        val result = ProfitCalculator.evaluate(
            TripInput(app = "Uber", fare = 180.0, totalKm = 14.0, minutes = 25.0),
            withCommission
        )
        // 180 * 0.75 = 135 - 41.70 = 93.30
        assertEquals(93.30, result.netProfit, 0.01)
    }

    @Test
    fun apenas_cuandoSoloCumpleUnaMeta() {
        // Ganancia por km alta, pero por hora baja (viaje muy lento).
        val result = ProfitCalculator.evaluate(
            TripInput(app = "DiDi", fare = 150.0, totalKm = 10.0, minutes = 90.0),
            settings
        )
        assertEquals(Verdict.APENAS, result.verdict)
    }
}
