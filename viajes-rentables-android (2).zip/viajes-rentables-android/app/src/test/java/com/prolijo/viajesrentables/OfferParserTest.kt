package com.prolijo.viajesrentables

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OfferParserTest {

    @Test
    fun ofertaTipica_conEtiquetas() {
        val parsed = OfferParser.parse(
            "Tarifa: \$180\nDistancia: 12 km\nRecogida: 2 km\nTiempo estimado: 25 min"
        )
        assertEquals(180.0, parsed.fare!!, 0.01)
        assertEquals(12.0, parsed.tripKm!!, 0.01)
        assertEquals(2.0, parsed.pickupKm!!, 0.01)
        assertEquals(14.0, parsed.totalKm!!, 0.01)
        assertEquals(25.0, parsed.minutes!!, 0.01)
        assertTrue(parsed.isComplete)
    }

    @Test
    fun ofertaSinRecogida() {
        val parsed = OfferParser.parse("\$95\n8 km\n15 minutos")
        assertEquals(95.0, parsed.fare!!, 0.01)
        assertEquals(8.0, parsed.totalKm!!, 0.01)
        assertEquals(15.0, parsed.minutes!!, 0.01)
    }

    @Test
    fun milesConComa_yDecimalConComa() {
        val parsed = OfferParser.parse("\$1,250\n12,5 km\n30 min")
        assertEquals(1250.0, parsed.fare!!, 0.01)
        assertEquals(12.5, parsed.totalKm!!, 0.01)
    }

    @Test
    fun textoIncompleto_noEsCompleto() {
        val parsed = OfferParser.parse("Nuevo viaje cerca de ti")
        assertNull(parsed.fare)
        assertTrue(!parsed.isComplete)
    }
}
