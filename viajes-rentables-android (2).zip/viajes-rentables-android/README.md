# Viajes Rentables — Uber y DiDi (Android)

App nativa de Android para Prolijo, conductor de Uber y DiDi en Monterrey, Nuevo León.

Cuando te cae una oferta en Uber Driver o DiDi Conductor, la app muestra una **burbuja flotante encima de la app** con el veredicto:

- 🟢 **SÍ CONVIENE**
- 🟠 **APENAS**
- 🔴 **NO CONVIENE**

Y además: ganancia neta, $/km, $/hora y el porqué, en palabras claras.

> **Importante: NO se entrega un APK ya compilado.** Este es el proyecto completo
> de Android Studio, listo para abrir, compilar e instalar. En este entorno
> no hay Java ni Android SDK, así que no se pudo compilar aquí. Sigue los
> pasos de abajo en una computadora con Android Studio.

---

## Qué hace

1. **Detecta la oferta en pantalla** con el servicio de accesibilidad
   (lee el texto visible de Uber Driver / DiDi Conductor: tarifa, km y minutos).
2. **Si el texto no alcanza**, hace una captura de pantalla y la lee con OCR
   en el teléfono (ML Kit, sin internet).
3. **Calcula la rentabilidad** con la misma lógica de la app web
   "Viajes Rentables - Uber y DiDi":
   - Ganancia neta = tarifa después de comisión − km totales × costo por km
   - Costo por km = precio de gasolina / rendimiento del auto + mantenimiento por km
   - $/km y $/hora, comparados con tus metas.
4. **Muestra la burbuja** con el veredicto. La puedes arrastrar con el dedo
   y cerrarla.
5. **Guarda el historial** en el teléfono (fecha, app, tarifa, km, minutos,
   veredicto) y un resumen de hoy.

## Qué NO hace (límites honestos)

- **No acepta ni rechaza viajes por ti.** Solo te aconseja. La decisión
  siempre es tuya, en la app de Uber / DiDi.
- **No usa ninguna API de Uber o DiDi.** No existe una API pública para
  recibir ofertas. La app lee lo que se ve en tu pantalla, nada más.
- **No envía tus datos a ningún servidor.** Todo se calcula y se guarda
  en tu teléfono.
- **No funciona sola sin permisos.** Necesita los 3 permisos de abajo.
  Sin el servicio de accesibilidad, no puede leer la oferta.

## ⚠️ Riesgo que debes conocer

Uber y DiDi pueden detectar apps que leen la pantalla o que se superponen
a sus apps de conductor, y eso **puede marcar tu cuenta o suspenderla**.
Esta app no toca botones ni acepta viajes, solo lee texto, pero el riesgo
existe. Úsala bajo tu responsabilidad, pruébala primero con viajes que
no te importen, y si Uber / DiDi te avisan de algo, desactívala de inmediato.

---

## Valores por defecto (ejemplos, cámbialos)

Son **ejemplos para Monterrey, no los datos reales de tu auto**:

| Ajuste | Ejemplo |
|---|---|
| Precio de gasolina | $24.90 MXN / litro |
| Rendimiento | 14.0 km / litro |
| Mantenimiento y otros | $1.20 MXN / km |
| Comisión | 0 % |
| Meta por km | $8.00 MXN netos / km |
| Meta por hora | $200.00 MXN netos / hora |

**Comisión en 0 %:** en México la oferta normalmente ya muestra lo que
te pagan a ti, no el total del pasajero. Si tu oferta es el total bruto,
sube la comisión en Ajustes (por ejemplo 25 % Uber, 20 % DiDi).

**Ejemplo de prueba** (botón "Probar burbuja" en la app):
DiDi, $180, 12 km de viaje + 2 km de recogida = 14 km, 25 min.
Costo por km: 24.90 / 14 + 1.20 = $2.98. Costo total: $41.70.
Ganancia: $138.30. Por km: $9.88. Por hora: $331.92. **SÍ CONVIENE.**

---

## Cómo abrirlo y compilarlo en Android Studio

### Lo que necesitas

- Una computadora con **Android Studio** (versión reciente, por ejemplo
  Ladybug o más nueva) con el **Android SDK 34** instalado.
- Un teléfono Android (Android 8.0 / API 26 o más nuevo) con Uber Driver
  y/o DiDi Conductor instalados.
- Cable USB o Wi-Fi para instalar la app en el teléfono.

### Pasos

1. **Copia esta carpeta** `viajes-rentables-android/` a tu computadora.
2. Abre **Android Studio** → **Open** → elige la carpeta
   `viajes-rentables-android/`.
3. Espera a que termine la sincronización de Gradle (descarga las
   dependencias, entre ellas ML Kit; necesita internet la primera vez).
4. Si Android Studio te pide instalar el SDK 34 o el JDK 17, acéptalo.
5. Conecta tu teléfono con **Depuración USB** activada
   (Ajustes → Opciones de desarrollador → Depuración USB).
6. En Android Studio, pulsa **Run ▶** (o **Build → Build App Bundle(s) /
   APK(s) → Build APK(s)** para generar el APK).
7. La app **Viajes Rentables** se instala en tu teléfono.

> No hay archivo `gradlew` en el proyecto: Android Studio usa su propio
> Gradle (8.7, según `gradle/wrapper/gradle-wrapper.properties`).
> Si quieres compilar por línea de comandos, instala Gradle 8.7 y corre
> `gradle wrapper` dentro de la carpeta, o usa el Gradle de Android Studio.

### Para correr los tests (opcional)

En Android Studio: clic derecho en `app/src/test/` → **Run 'Tests in...'**.
Hay tests de la calculadora (`ProfitCalculatorTest`) y del lector de
ofertas (`OfferParserTest`).

---

## Cómo activarla en el teléfono (3 permisos)

Hazlo en este orden, dentro de la app **Viajes Rentables**:

### 1. Mostrar sobre otras apps (obligatorio)
- En la app, pulsa **"1. Permitir mostrar sobre otras apps"**.
- Activa **"Permitir mostrar sobre otras apps"** para Viajes Rentables.
- Sin esto, la burbuja no puede aparecer encima de Uber / DiDi.

### 2. Servicio de accesibilidad (obligatorio)
- En la app, pulsa **"2. Activar servicio de accesibilidad"**.
- Se abre Ajustes del teléfono → Accesibilidad.
- Busca **"Viajes Rentables — lector de ofertas"** y actívalo.
- Acepta el aviso de Android. Este permiso es el que permite leer
  el texto de la oferta en pantalla.

### 3. Captura de pantalla para OCR (opcional)
- En la app, pulsa **"3. Permitir captura de pantalla (OCR, opcional)"**.
- Acepta el aviso del sistema.
- Solo se usa si el texto de accesibilidad no trae los datos completos.
  Si no lo das, la app sigue funcionando con el texto de la pantalla.

### 4. Activa la burbuja
- En la app, enciende el interruptor **"Activar burbuja sobre Uber / DiDi"**.
- Ajusta primero tus valores reales en **"Tu auto y tus metas"** y pulsa
  **"Guardar ajustes"**.

### 5. Prueba
- Pulsa **"Probar burbuja con un viaje de ejemplo"**: debe aparecer la
  tarjeta flotante con SÍ CONVIENE ($180, 14 km, 25 min).
- Después abre Uber Driver o DiDi Conductor y espera una oferta real.
  Cuando aparezca, la burbuja debe mostrar el veredicto en unos segundos.
- Si no aparece: revisa que el interruptor esté encendido, que la
  accesibilidad esté activada y que la oferta muestre tarifa, km y minutos.

Para apagarla: apaga el interruptor en la app. Para desinstalarla:
desactívala primero en Accesibilidad y luego desinstálala normal.

---

## Archivos del proyecto

```
viajes-rentables-android/
├── README.md
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts            # minSdk 26, targetSdk 34, ML Kit OCR
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── java/com/prolijo/viajesrentables/
        │   │   ├── MainActivity.kt              # ajustes, permisos, historial
        │   │   ├── ProfitCalculator.kt          # calculadora pura (misma lógica web)
        │   │   ├── OfferParser.kt               # extrae $, km y min del texto
        │   │   ├── SettingsStore.kt             # ajustes en SharedPreferences
        │   │   ├── TripHistoryStore.kt          # historial local (JSON)
        │   │   ├── OfferAccessibilityService.kt # detecta Uber/DiDi y lee la oferta
        │   │   ├── OverlayService.kt            # burbuja flotante (foreground service)
        │   │   ├── OcrHelper.kt                 # ML Kit Text Recognition
        │   │   └── ScreenCaptureHelper.kt       # MediaProjection (captura + OCR)
        │   └── res/
        │       ├── layout/activity_main.xml     # pantalla principal
        │       ├── layout/overlay_card.xml      # tarjeta flotante
        │       ├── values/strings.xml, themes.xml, colors.xml
        │       ├── xml/accessibility_service_config.xml
        │       ├── drawable/ic_launcher_*.xml
        │       └── mipmap-anydpi-v26/ic_launcher*.xml
        └── test/java/com/prolijo/viajesrentables/
            ├── ProfitCalculatorTest.kt
            └── OfferParserTest.kt
```

### Decisiones de arquitectura

- **Kotlin, minSdk 26, targetSdk 34.** Sin librerías de más.
- **Primero texto de accesibilidad, OCR como respaldo.** Leer los nodos
  de la pantalla es más fiable y no necesita captura; la captura con
  MediaProjection + ML Kit solo entra si faltan datos.
- **Calculadora pura (`ProfitCalculator`).** No depende de Android, por
  eso se puede probar con tests unitarios.
- **Historial simple (SharedPreferences + JSON).** Sin Room, para que el
  proyecto sea más fácil de compilar y mantener. Guarda los últimos
  200 viajes.
- **Nunca auto-acepta.** No hay código que toque botones de Uber / DiDi.
  Esa es una decisión a propósito, no algo que falte.

---

## Si algo falla

| Problema | Qué revisar |
|---|---|
| No aparece la burbuja | Interruptor encendido, permiso de superposición, servicio en primer plano activo |
| La burbuja no lee la oferta | Servicio de accesibilidad activado para Viajes Rentables; la oferta debe mostrar tarifa, km y minutos |
| El OCR no lee nada | Permiso de captura de pantalla aceptado; prueba de nuevo con buena luz / texto claro |
| Los números no cuadran | Revisa tus ajustes: gasolina, rendimiento, comisión y metas. Los valores de ejemplo no son los de tu auto |
| Gradle no sincroniza | Internet la primera vez, SDK 34 instalado, JDK 17 en Android Studio |

---

*Hecho para Prolijo — Prolijo Multiservicios Residenciales, Monterrey / Juárez, NL.
La app web "Viajes Rentables - Uber y DiDi" sigue disponible para calcular
viajes a mano cuando no quieras usar la burbuja.*
